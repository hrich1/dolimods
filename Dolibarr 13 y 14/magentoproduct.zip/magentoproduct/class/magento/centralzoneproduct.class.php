<?php

/**
 *  \file       dev/skeletons/cenralzoneentrepotsync.class.php
 *  \ingroup    mymodule othermodule1 othermodule2
 *  \brief      This file is an example for a CRUD class file (Create/Read/Update/Delete)
 *				Initialy built by build_class_from_table on 2016-02-01 16:04
 */

// Put here all includes required by your class file
//require_once(DOL_DOCUMENT_ROOT."/core/class/commonobject.class.php");
require_once(DOL_DOCUMENT_ROOT."/magentosync/class/magento/centralzonesoap.class.php");
//require_once(DOL_DOCUMENT_ROOT."/societe/class/societe.class.php");
//require_once(DOL_DOCUMENT_ROOT."/product/class/product.class.php");


/**
 *	Put here description of your class
 */
class Centralzoneproduct extends Centralzonesoap
{

    private $_client;

    /**
     *  Constructor
     *
     *  @param	DoliDb		$db      Database handler
     */
    function __construct($db)
    {
        parent::__construct($db);

        //$this->db = $db;
        //return 1;
    }
    
    /**
     *  Create object into database
     *
     *  @param	User	$user        User that creates
     *  @param  int		$notrigger   0=launch triggers after, 1=disable triggers
     *  @return int      		   	 <0 if KO, Id of created object if OK
     */
    function create($ref, $product_data)
    {
        $result = NULL;
        
        $attributeSets = $this->call('product_attribute_set.list');
        $attribute = 0;
        foreach ($attributeSets as $attribute_item) {
            $attribute = $attribute_item['set_id'];
        }
        //$attributeSet = current($attributeSets);
        //var_dump($attribute);
        try{
            $result = $this->call('catalog_product.create', array('simple',$attribute,$ref, $product_data));
        }catch(Exception $e){
            //echo $e->getMessage();
            //exit();
            return false;
        }
        //exit();
        return $result;
    }

    
    /**
     *  Load object in memory from the database
     *
     *  @param	int		$id    	Id object
     *  @param	string	$ref	Ref
     *  @return int          	<0 if KO, >0 if OK
     */
    function fetch($id=0, $ref=NULL)
    {
        $attributes = array('set','type','categories','websites','created_at','updated_at','type_id','name','description','short_description','weight','status','url_key','url_path','visibility','category_ids','website_ids','price','tax_class_id','meta_title','meta_keyword','meta_description');
        $data  =array('productId'=>NULL,'storeView'=>'1','attributes'=>$attributes, 'identifierType'=>'SKU');
        $data['productId'] = ($id>0)?$id:$ref;
        $data['identifierType'] = ($id>0)?'ID':'SKU';
        try{
            $result = $this->call('catalog_product.info', $data);
            //var_dump($result);
        }catch(Exception $e){
            //echo $e->getMessage();
            return false;
        }
        
        return $result;
    }


    /**
     *  Update object into database
     *
     *  @param	User	$user        User that modifies
     *  @param  int		$notrigger	 0=launch triggers after, 1=disable triggers
     *  @return int     		   	 <0 if KO, >0 if OK
     */
    function update($id, $product_data = array())
    {
        $result = false;
        $data = array('productId'=>$id, 'productData'=>$product_data, 'storeView'=>NULL,'identifierType'=>'ID');   
        try{
            $result = $this->call('catalog_product.update', $data);
        }  catch (Exception $e){
            //echo $e->getMessage();
            return false;
        }
        return $result;
    }
    

    /**
     *  Update object into database
     *
     *  @param	User	$user        User that modifies
     *  @param  int		$notrigger	 0=launch triggers after, 1=disable triggers
     *  @return int     		   	 <0 if KO, >0 if OK
     */
    function updateStock($id, $qty)
    {
        $result = false;
        $attributes = array('qty'=>$qty, 'is_in_stock'=>1);
        if($qty <= 0)
            $attributes['is_in_stock'] = 0;
        
        $data = array('productId'=>$id, 'productData'=>array('stock_data'=> $attributes), 'storeView'=>NULL,'identifierType'=>'ID');
        
        try{
            $result = $this->call('catalog_product.update', $data);
        }  catch (Exception $e){
            //echo $e->getMessage();
            return false;
        }
        return $result;
    }
    
    
    /**
     *  Update object into database
     *
     *  @param	User	$user        User that modifies
     *  @param  int		$notrigger	 0=launch triggers after, 1=disable triggers
     *  @return int     		   	 <0 if KO, >0 if OK
     */
    function getStock($id, $entrepot)
    {
    	global $conf, $langs;
        $error=0;
        $sql = "SELECT e.rowid, e.label, ps.reel, ps.pmp, ps.rowid as product_stock_id";
        $sql.= " FROM ".MAIN_DB_PREFIX."entrepot as e,";
        $sql.= " ".MAIN_DB_PREFIX."product_stock as ps";
        $sql.= " WHERE ps.reel != 0";
        $sql.= " AND ps.fk_entrepot = e.rowid";
        $sql.= " AND e.entity = ".$conf->entity;
        $sql.= " AND ps.fk_product = ".$id;
        $sql.= " AND ps.fk_entrepot = ".$entrepot;
        $sql.= " ORDER BY e.label";
        
        $resql=$this->db->query($sql);
        if ($resql)
        {
            $num = $this->db->num_rows($resql);
            if($num>0)
            {
                while ($i < $num)
                {
                    $obj = $this->db->fetch_object($resql);
                    return $obj->reel;
                }
            }else{
                return 0;
            }
        }
        return 0;
    }
    
    

    /**
     *  Delete object in database
     *
     *	@param  User	$user        User that deletes
     *  @param  int		$notrigger	 0=launch triggers after, 1=disable triggers
     *  @return	int					 <0 if KO, >0 if OK
     */
    function delete($ref)
    {
        //global $conf, $langs;
        $error=0;

        $product_data = array(
            'status'=>0
        );

        $result = $this->call('catalog_product.update', array($ref, $product_data));
        return true;
    }
}
