<?php
/**
 *  \file       htdocs/core/triggers/interface_90_all_Rent.class.php
 *  \ingroup    core
 *  \brief      Fichier de demo de personalisation des actions du workflow
 *  \remarks    Son propre fichier d'actions peut etre cree par recopie de celui-ci:
 *              - Le nom du fichier doit etre: interface_99_modMymodule_Mytrigger.class.php
 *				                           ou: interface_99_all_Mytrigger.class.php
 *              - Le fichier doit rester stocke dans core/triggers
 *              - Le nom de la classe doit etre InterfaceMytrigger
 *              - Le nom de la propriete name doit etre Mytrigger
 */
require_once DOL_DOCUMENT_ROOT.'/core/triggers/dolibarrtriggers.class.php';
require_once dol_buildpath('/magentoproduct/class/magento/centralzoneproduct.class.php');
require_once dol_buildpath('/product/class/product.class.php');


/**
 *  Class of triggers for demo module
 */
class InterfaceMagentoproduct extends DolibarrTriggers
{

    public $family = 'magentoproduct';
    public $picto = 'magentoproduct@magentoproduct';
    public $description = "Triggers of this module manage syncro product  by magentoproduct.";
    public $version = self::VERSION_DOLIBARR;
    /**
     * Function called when a Dolibarrr business event is done.
	 * All functions "runTrigger" are triggered if file is inside directory htdocs/core/triggers or htdocs/module/code/triggers (and declared)
     *
     * @param string		$action		Event action code
     * @param Object		$object     Object
     * @param User		    $user       Object user
     * @param Translate 	$langs      Object langs
     * @param conf		    $conf       Object conf
     * @return int         				<0 if KO, 0 if no triggered ran, >0 if OK
     */
    public function runTrigger($action, $object, User $user, Translate $langs, Conf $conf)
    {
        // Put here code you want to execute when a Dolibarr business events occurs.
        // Data and type of action are stored into $object and $action
        global $db;
        $this->db = $db;
        $product_exist = true;
        $data_product = array();   
        $langs->load("magentoproduct@magentoproduct");
        
        //setEventMessages($action.'----', null, 'warnings');
        switch ($action) 
        {
            case 'PRODUCT_CREATE':
                //var_dump($object);
                //exit();
                if($conf->global->MAGENTOSYNC_STATUS)
                {
                    $magentosync_client = new Centralzoneproduct($this->db);
                    
                    $status = ($product->status==0)?2:$product->status;
                    $weight = 0;
                    if($product->weight >0)
                        $weight = $product->weight;
                    $params = array('name'=>$object->label, 'description'=> $object->description, 'short_description'=> $object->description, 'weight'=>$weight, 'status'=>$status,'visibility'=>'4','meta_title'=>$object->label,'meta_description'=>$object->description,'website_ids'=>array(1), 'price'=> $object->price_ttc);
                    
                    if(!$magentosync_client->create($object->ref, $params))
                    {
                        setEventMessages($langs->trans('CantCreateProduct'), null, 'warnings');
                    } 
                }
                
                break;
            
            case 'PRODUCT_MODIFY':
                if($conf->global->MAGENTOSYNC_STATUS)
                {
                    //Producto Dolibarr para obtener ID
                    $product = new Product($db);
                    $product->fetch($object->id);
                    
                    $magentosync_client = new Centralzoneproduct($this->db);
                    //Get product Magento Sync
                    $result_mage = $magentosync_client->fetch(0,$product->ref);
                    //If no exis magento producto return false
                    if(!$result_mage){
                        setEventMessages($langs->trans('MagentoProductNoFound'), null, 'warnings');
                        return true;
                    }
                    //Valid SKU Match
                    if($result_mage['sku']!=$product->ref)
                    {
                        setEventMessages($langs->trans('SkuNotMatch'), null, 'warnings');
                        return true;
                    }
                    //Update Product
                    $data_product['name'] = $product->label;
                    
                    $data_product['short_description'] = $product->description;
                    $data_product['description'] = $product->description;   
                    if($product->weight != '' and $product->weight > 0)
                        $data_product['weight'] = $product->weight;
                    $data_product['dolibarr_id'] = $product->id;
                    $data_product['status'] = ($product->status==0)?2:$product->status;
                    
                    //var_dump($data_product);
                    if(!$magentosync_client->update($result_mage['product_id'],$data_product))
                    {
                        setEventMessages($langs->trans('CantUpdateProductInfo'), null, 'warnings');
                    }    
                }
                
                break;
                
            case 'PRODUCT_DELETE':
                //setEventMessages($langs->trans('PRODUCT_DELETE'), null, 'warnings');
                break;
            
            case 'PRODUCT_PRICE_MODIFY':
                if($conf->global->MAGENTOSYNC_STATUS)
                {
                    //Producto Dolibarr para obtener ID
                    $product = new Product($db);
                    $product->fetch($object->id);
                    
                    $magentosync_client = new Centralzoneproduct($this->db);
                    //Get product Magento Sync
                    $result_mage = $magentosync_client->fetch(0,$product->ref);
                    //If no exis magento producto return false
                    if(!$result_mage){
                        setEventMessages($langs->trans('MagentoProductNoFound'), null, 'warnings');
                        return true;
                    }
                    //Valid SKU Match
                    if($result_mage['sku']!=$product->ref)
                    {
                        setEventMessages($langs->trans('SkuNotMatch'), null, 'warnings');
                        return true;
                    }
                    
                    $data_product = array('price'=>99999.99);
                    //Update Product
                    if(isset($product->multiprices_ttc) and count($product->multiprices_ttc)>0)
                    {
                        $data_product['price'] = number_format($product->multiprices_ttc[1], 2, '.', '');
                    }else{
                        $data_product['price'] = number_format($product->price_ttc, 2, '.', '');
                    }
                    //var_dump($data_product);
                    if(!$magentosync_client->update($result_mage['product_id'],$data_product))
                    {
                        setEventMessages($langs->trans('CantUpdateProductPrice'), null, 'warnings');
                    }    
                }
                
                break;
            
            case 'STOCK_MOVEMENT':
                if($conf->global->MAGENTOSYNC_STATUS)
                {
                    //Producto Dolibarr para obtener ID
                    $product = new Product($db);
                    $product->fetch($object->product_id);
                    
                    $product_exist = true;
                    $magentosync_client = new Centralzoneproduct($this->db);
                    //Get product Magento Sync
                    $result_mage = $magentosync_client->fetch(0,$product->ref);
                    //If no exis magento producto return false
                    if(!$result_mage){
                        setEventMessages($langs->trans('MagentoProductNoFound'), null, 'warnings');
                        return true;
                    }
                    //Valid SKU Match
                    if($result_mage['sku']!=$product->ref)
                    {
                        setEventMessages($langs->trans('SkuNotMatch'), null, 'warnings');
                        return true;
                    }
                    //Update Stock
                    if($object->entrepot_id)
                    {
                        if($conf->global->MAGENTOSYNC_WHAREHOUSE == $object->entrepot_id)
                        {
                            $stock = $magentosync_client->getStock($product->id, $object->entrepot_id);
                            
                            if(!$magentosync_client->updateStock($result_mage['product_id'], $stock))
                            {
                                setEventMessages($langs->trans('CantUpdateProductStock'), null, 'warnings');
                            }
                        }
                    }    
                }
                
                break;
            default :
                break;
        }

        return 0;
    }
    
}
