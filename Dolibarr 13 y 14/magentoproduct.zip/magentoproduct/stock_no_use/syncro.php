<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/magentosync/class/cenralzoneentrepotsync.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/entrepot.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/stock.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';

$langs->load("magentosync");
$langs->load("products");
$langs->load("stocks");
$langs->load("companies");

// Get parameters
$ref		= GETPOST('ref','int');
$action		= GETPOST('action','alpha');
$backtopage     = GETPOST('backtopage');
$myparam	= GETPOST('myparam','alpha');

// Protection if external user
if ($user->societe_id > 0)
{
    accessforbidden();
}

if (empty($action) && empty($id) && empty($ref)) $action='create';

// Load object if id or ref is provided as parameter
$object = new Cenralzoneentrepotsync($db);
if (($id > 0 || ! empty($ref)) && $action != 'add')
{
    $result=$object->fetch($id,$ref);
    if ($result < 0) dol_print_error($db);
}

/*******************************************************************
 * ACTIONS
 *
 * Put here all code to do according to value of "action" parameter
 ********************************************************************/
// Action to add record
if ($action == 'add')
{
    if (GETPOST('cancel'))
    {
        $urltogo=$backtopage?$backtopage:dol_buildpath('/product/stock/card.php?id='.$ref,1);
        header("Location: ".$urltogo);
        exit;
    }

    $error=0;

    /* object_prop_getpost_prop */
    //$object->id = GETPOST("id");
    $object->reference = GETPOST("reference"); 
    $object->description = GETPOST("description");
    $object->url = GETPOST("url");
    $object->user = GETPOST("user"); 
    $object->pwd = GETPOST("pwd");
    $object->status = GETPOST("status");
    $object->fk_entrepot = GETPOST("ref");

    if (empty($object->fk_entrepot))
    {
        $error++;
        setEventMessage($langs->trans("ErrorFieldRequired",$langs->transnoentitiesnoconv("Ref")),'errors');
    }

    if (! $error)
    {
        $result=$object->create($user);
        if ($result > 0)
        {
            // Creation OK
            $urltogo=$backtopage?$backtopage:dol_buildpath('/magentosync/stock/syncro.php?ref='.$object->fk_entrepot ,1);
            header("Location: ".$urltogo);
            exit;
        }
        {
            // Creation KO
            if (! empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
            else  setEventMessages($object->error, null, 'errors');
            $action='create';
        }
    }
    else
    {
        $action='create';
    }
}

// Cancel
if ($action == 'update' && GETPOST('cancel')) $action='view';

// Action to update record
if ($action == 'update' && ! GETPOST('cancel'))
{
    $error=0;
    
    $object->id = GETPOST("id");
    $object->reference = GETPOST("reference"); 
    $object->description = GETPOST("description");
    $object->url = GETPOST("url");
    $object->user = GETPOST("user"); 
    $object->pwd = GETPOST("pwd");
    $object->status = GETPOST("status");
    $object->fk_entrepot = GETPOST("ref");

    if (empty($object->fk_entrepot))
    {
        $error++;
        setEventMessages($langs->trans("ErrorFieldRequired",$langs->transnoentitiesnoconv("Ref")),null,'errors');
    }

    if (! $error)
    {
        $result=$object->update($user);
        if ($result > 0)
        {
            $action='view';
        }
        else
        {
            // Creation KO
            if (! empty($object->errors)) setEventMessages(null, $object->errors, 'errors');
            else setEventMessages($object->error, null, 'errors');
            $action='edit';
        }
    }
    else
    {
        $action='edit';
    }
}

// Action to delete
if ($action == 'confirm_delete')
{
    $result=$object->delete($user);
    if ($result > 0)
    {
        // Delete OK
        setEventMessages($langs->trans("RecordDeleted"), null, 'mesgs');
        header("Location: ".dol_buildpath('/magentosync/stock/syncro.php?ref='.$object->fk_entrepot,1));
        exit;
    }
    else
    {
        if (! empty($object->errors)) setEventMessages(null,$object->errors,'errors');
        else setEventMessages($object->error,null,'errors');
    }
}

/***************************************************
 * VIEW
 *
 * Put here all code to build page
 ****************************************************/

llxHeader('','Magento Sync Stock','');

$form=new Form($db);


// Put here content of your page

// Example : Adding jquery code
print '<script type="text/javascript" language="javascript">
/*jQuery(document).ready(function() {
	function init_myfunc()
	{
		jQuery("#myid").removeAttr(\'disabled\');
		jQuery("#myid").attr(\'disabled\',\'disabled\');
	}
	init_myfunc();
	jQuery("#mybutton").click(function() {
		init_needroot();
	});
});*/
</script>';


// Part to show a list

if(!isset($object->id))
    $action='create';

// Part to create
if ($action == 'create')
{
    print_fiche_titre($langs->trans("NewResidence"));

    //dol_fiche_head();
    print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'?ref='.$ref.'">';
    print '<input type="hidden" name="action" value="add">';
    print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
    print '<input type="hidden" name="ref" value="'.$ref.'">';
    print '<table width="100%" class="border">
            <tbody>
                <tr>
                    <td width="25%" class="fieldrequired">'.$langs->trans("Reference Store").'</td>
                    <td colspan="3"><input type="text" name="reference" value=""></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Description").'</td>
                    <td colspan="3"><input type="text" name="description" value="" size="40"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Url").'</td>
                    <td colspan="3"><input type="text" name="url" value="" size="40"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("User").'</td>
                    <td colspan="3"><input type="text" name="user" value=""></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Password").'</td>
                    <td colspan="3"><input type="password" name="pwd" value=""></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Status").'</td>
                    <td colspan="3">
                        <select name="status">
                            <option value="0">Disabled</option>
                            <option value="1">Enabled</option>
                            
                                
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>'."\n";
    
    print '<br>';
    
    print '<center><input type="submit" class="button" name="add" value="'.$langs->trans("Create").'"> &nbsp; <input type="submit" class="button" name="cancel" value="'.$langs->trans("Cancel").'"></center>';

    print '</form>';

    //dol_fiche_end();
}



// Part to edit record
if (($id || $ref) && $action == 'edit')
{
   // dol_fiche_head();
    print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'?ref='.$ref.'">';
    print '<input type="hidden" name="action" value="update">';
    print '<input type="hidden" name="backtopage" value="'.$backtopage.'">';
    print '<input type="hidden" name="id" value="'.$object->id.'">';
    print '<input type="hidden" name="ref" value="'.$object->fk_entrepot.'">';
    print '<table width="100%" class="border">
            <tbody>
                <tr>
                    <td width="25%" class="fieldrequired">'.$langs->trans("Reference Store").'</td>
                    <td colspan="3"><input type="text" name="reference" value="'.$object->reference.'"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Description").'</td>
                    <td colspan="3"><input type="text" name="description" value="'.$object->description.'" size="40"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Url").'</td>
                    <td colspan="3"><input type="text" name="url" value="'.$object->url.'" size="40"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("User").'</td>
                    <td colspan="3"><input type="text" name="user" value="'.$object->user.'"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Password").'</td>
                    <td colspan="3"><input type="password" name="pwd" value="'.$object->pwd.'"></td>
                </tr>
                <tr>
                    <td class="fieldrequired">'.$langs->trans("Status").'</td>
                    <td colspan="3">
                        <select name="status">
                            <option value="0" '.((isset($object->status) and $object->status==0)?'selected':'').'>Disabled</option>
                            <option value="1" '.((isset($object->status) and $object->status==1)?'selected':'').'>Enabled</option>
                            
                                
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>'."\n";
    
    print '<br>';
    print '<center><input type="submit" class="button" name="update" value="'.$langs->trans("Modify").'">&nbsp;<input type="submit" value="'.$langs->trans("Cancel").'" name="cancel" class="button"></center>';

    print '</form>';

   // dol_fiche_end();
}

$form=new Form($db);

// Part to show record
if (($id || $ref) && (empty($action) || ($action == 'view' || $action == 'delete') ))
{
    
    $object_entrepot = new Entrepot($db);
    $result = $object_entrepot->fetch($ref);
    if ($result < 0)
    {
        dol_print_error($db);
    }
    
    $head = stock_prepare_head($object_entrepot);
	dol_fiche_head($head, 'card', $langs->trans("Warehouse"), 0, 'stock');
	
	if ($action == 'delete')
	{
	    print $form->formconfirm($_SERVER["PHP_SELF"]."?ref=".$object->fk_entrepot,$langs->trans("DeleteMagentoSyncro"),$langs->trans("ConfirmDeleteWarehouse",$object->libelle),"confirm_delete",'',0,2);
	}
	
    if ($user->rights->magentosync->view)
    {
        print '<table width="100%" class="border">
        <tbody>
            <tr>
                <td width="25%">'.$langs->trans("Reference Store").'</td>
                <td colspan="3">'.$object->reference.'</td>
            </tr>
            <tr>
                <td>'.$langs->trans("Description").'</td>
                <td colspan="3">'.$object->description.'</td>
            </tr>
            <tr>
                <td valign="top">'.$langs->trans("Url").'</td>
                <td colspan="3">'.$object->url.'</td>
            </tr>
            <tr>
                <td valign="top">'.$langs->trans("User").'</td>
                <td colspan="3">'.$object->user.'</td>
            </tr>        
            <tr>
                <td valign="top">'.$langs->trans("Password").'</td>
                <td colspan="3">*********</td>
            </tr>
            <tr>
                <td valign="top">'.$langs->trans("Status").'</td>
                <td colspan="3">'.((isset($object->status) and $object->status)?'Enabled':'Disabled').'</td>
            </tr>
        </tbody>
                </table>'."\n";
    }
    
    dol_fiche_end();


    // Buttons
    print '<div class="tabsAction">'."\n";
    $parameters=array();
    $reshook=$hookmanager->executeHooks('addMoreActionsButtons',$parameters,$object,$action);    // Note that $action and $object may have been modified by hook
    if ($reshook < 0) setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');

    if (empty($reshook))
    {
        
        if ($user->rights->magentosync->write)
        {
            print '<div class="inline-block divButAction"><a class="butAction" href="'.$_SERVER["PHP_SELF"].'?ref='.$object->fk_entrepot.'&amp;action=edit">'.$langs->trans("Modify").'</a></div>'."\n";
        }

        if ($user->rights->magentosync->delete)
        {
            print '<div class="inline-block divButAction"><a class="butActionDelete" href="'.$_SERVER["PHP_SELF"].'?ref='.$object->fk_entrepot.'&amp;action=delete">'.$langs->trans('Delete').'</a></div>'."\n";
        }
    }
    print '</div>'."\n";


    // Example 2 : Adding links to objects
    // The class must extends CommonObject class to have this method available
    //$somethingshown=$object->showLinkedObjectBlock();

}


// End of page
llxFooter();
$db->close();

?>
                
                
                
                