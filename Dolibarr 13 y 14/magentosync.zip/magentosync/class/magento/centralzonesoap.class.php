<?php

/**
 *  \file       dev/skeletons/cenralzoneentrepotsync.class.php
 *  \ingroup    mymodule othermodule1 othermodule2
 *  \brief      This file is an example for a CRUD class file (Create/Read/Update/Delete)
 *				Initialy built by build_class_from_table on 2016-02-01 16:04
 */

// Put here all includes required by your class file
require_once(DOL_DOCUMENT_ROOT."/core/class/commonobject.class.php");
//require_once(DOL_DOCUMENT_ROOT."/societe/class/societe.class.php");
//require_once(DOL_DOCUMENT_ROOT."/product/class/product.class.php");


/**
 *	Put here description of your class
 */
class Centralzonesoap extends CommonObject
{

    private $_client;

    /**
     *  Constructor
     *
     *  @param	DoliDb		$db      Database handler
     */
    function __construct($db)
    {
        $this->db = $db;
        return 1;
    }

    /**
     *  Create object into database
     *
     *  @param	User	$user        User that creates
     *  @param  int		$notrigger   0=launch triggers after, 1=disable triggers
     *  @return int      		   	 <0 if KO, Id of created object if OK
     */
    private function connectMage()
    {
        global  $conf;
        $error=0;
    	$this->_client = new SoapClient($conf->global->MAGENTOSYNC_URL);
        $session = $this->_client->login($conf->global->MAGENTOSYNC_USER, $conf->global->MAGENTOSYNC_PWD);
        
        return $session;
    }
    
    /**
     *  Create object into database
     *
     *  @param	User	$user        User that creates
     *  @param  int		$notrigger   0=launch triggers after, 1=disable triggers
     *  @return int      		   	 <0 if KO, Id of created object if OK
     */
    function call($action, $params=array())
    {
    	$result = NULL;
        
        $session = $this->connectMage();
        if(count($params)>0)
            $result = $this->_client->call($session, $action, $params);
        else
            $result = $this->_client->call($session, $action);

        return $result;
    }

}
